These are all the Lua files for adding the CU weapons to Core3. 

As you can see from the screenshot some of the weapons have naming issues but i�m not going to touch the .tre files at this time.


The weapon stats and certifications are also wrong but easily changed or customised to suit.

I have put the weapons into a folder called /ep3 to make it easier to reload them should you have to reinstall your server, also included are the object.lua and serverobject.lus files you just need to copy the appropriate paths from each to the ones already on the server.

And for the really lazy.

There is a cut from the blue frog file to paste in the appropriate place.